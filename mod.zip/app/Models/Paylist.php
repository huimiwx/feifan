<?php

namespace App\Models;

class Paylist extends Model
{
    protected $connection = "default";
    protected $table = 'paylist';
}

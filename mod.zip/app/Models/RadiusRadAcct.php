<?php

namespace App\Models;

class RadiusRadAcct extends Model
{
    protected $connection = "radius";
    protected $table = "radacct";
}
